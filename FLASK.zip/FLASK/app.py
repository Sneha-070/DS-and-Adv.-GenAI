from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    user_name_upper = None

    if request.method == 'POST':
        # Get name from form input
        user_name = request.form.get('username', 'Guest')
        # Convert to uppercase
        user_name_upper = user_name.upper()

    return render_template('index.html', name=user_name_upper)

if __name__ == '__main__':
    app.run(debug=True)